# Generated manually for phased canonical Department cutover.

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("academics", "0001_initial"),
        ("rotations", "0003_hospitaldepartment_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="historicalrotation",
            name="department",
            field=models.ForeignKey(
                blank=True,
                db_index=False,
                db_constraint=False,
                help_text="Canonical academic department where rotation takes place",
                null=True,
                on_delete=django.db.models.deletion.DO_NOTHING,
                related_name="+",
                to="academics.department",
            ),
        ),
        migrations.AddField(
            model_name="rotation",
            name="department",
            field=models.ForeignKey(
                blank=True,
                help_text="Canonical academic department where rotation takes place",
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name="canonical_rotations",
                to="academics.department",
            ),
        ),
    ]
